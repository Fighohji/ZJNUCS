#! /usr/bin/env python
#coding=utf-8

S= [(0, 'eps', 1), (1, 'eps', 2), (2, 'a', 3), (3, 'eps', 6), (1, 'eps', 4), (4, 'b', 5), (5, 'eps', 6), (6, 'eps', 1), (0, 'eps', 7), (6, 'eps', 7), (7, 'a', 8), (8, 'b', 9)]

def e_closure(p):
    T = []
    T1 = p
    
    while len(T) != len(T1):
        T = T1
        for q in T:
            for a, sym, c in S:
                if a == q and sym=='eps' and c not in T1:
                    T1.append(c)
    T1.sort()
    return T1

def move(p, x):
    T1 = []
    for q in p:
        for a, sym, c in S:
            if a == q and sym == x and c not in T1:
                T1.append(c)
    T1 = e_closure(T1)
    return T1

re = [e_closure([0])]

edge=[]

def work(x):
    p = 0
    for i in re:
        j = move(i, x)
        if j not in re:
            re.append(j)
            p = 1
        if (i, x, j) not in edge:
            edge.append((i, x, j))
    return p

while True:
    p = work('a') + work('b')
    if p == 0:
        break

for i in re:
    print(i)

def get_pos(t):
    i = -1
    for k in re:
        i += 1
        if t == k:
            return i

DFA = []

for u, w, v in edge:
    DFA.append((get_pos(u), w, get_pos(v)))

for i in DFA:
    print(i)

string = 'aabbab' # string = input()
n = len(string)
nw = 0
accept = 0

for i in range(n):
    for u, w, v in DFA:
        if  u == nw and w == string[i]:
            nw = v
            accept += 1
            break

if accept < n:
    print("\n字符串" + string +"被拒绝")
else:
    print("\n字符串" +string +"被接受")
